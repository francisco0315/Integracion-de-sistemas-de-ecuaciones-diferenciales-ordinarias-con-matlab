function dx=funcion(t, x);
Ip=0.0079; Mc=0.7031; lp=0.3302; Mp=0.23; Fc=0; Beq=4.3; g=9.81; Bp=0.0024;
dx = zeros(4, 1); 

X_1=x(1);
X_2=x(2);
alpha = x(3);
alpha2_2 = x(4);

sen_alpha = sin(x(3));
cos_alpha = cos(x(3));
alpha_pot = x(4)^2;

dx(1) = X_2;
dx(2) = (1/((Mc+Mp)*Ip + Mc*Mp*lp*lp + Mp*Mp*lp*lp*sen_alpha^2)) * ((Ip+Mp*lp*lp)*Fc + Mp*Mp*lp*lp*g*cos_alpha*sen_alpha - (Ip+Mp*lp*lp)*Beq*X_2 - (Ip*Mp*lp-Mp*Mp*lp*lp*lp)*alpha_pot*sen_alpha - Mp*lp*alpha2_2*cos_alpha*Bp);
dx(3) = alpha2_2;
dx(4) = (1/((Mc+Mp)*Ip + Mc*Mp*lp*lp + Mp*Mp*lp*lp*sen_alpha^2)) * ((Mc+Mp)*Mp*g*lp*sen_alpha - (Mc+Mp)*Bp*alpha2_2 + Fc*Mp*lp*cos_alpha - Mp*Mp*lp*lp*alpha_pot*sen_alpha*cos_alpha - Beq*Mp*lp*X_2*cos_alpha);
end
