x0 = [0; 0; pi/180; 0]; 
tspan = [0 10];
[t, x] = ode45(@funcion, tspan, x0);

subplot(2,1,1);
plot(t, x(:,1), 'y', 'LineWidth', 2);
grid on;

subplot(2,1,2);
plot(t, x(:,3), 'y', 'LineWidth', 2);
grid on;